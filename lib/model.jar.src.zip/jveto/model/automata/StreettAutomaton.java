package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents a Streett automaton.
 */
@XStreamAlias("StreettAutomaton")
public class StreettAutomaton extends SimpleAutomaton<Pair> {

}
