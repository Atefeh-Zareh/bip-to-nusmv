package jveto.model.automata;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents a very simple automaton.
 */
public abstract class Automaton {
	@XStreamAlias("States")
	/*
	 * * The list of states.
	 */
	private List<State> states;

	@XStreamAlias("Alphabet")
	/*
	 * * The alphabet.
	 */
	private Set<String> alphabet;

	@XStreamAlias("Description")
	/*
	 * * The automaton's description.
	 */
	private String description;
	
	/**
	 * Constructor.
	 */
	public Automaton() {
		alphabet = new HashSet<String>();
		states = new ArrayList<State>();
	}

	/**
	 * Sets the list of states.
	 * 
	 * @param states
	 *            a list of states.
	 */
	public void setStates(List<State> states) {
		this.states = states;
	}

	/**
	 * Gets the list of states.
	 * 
	 * @return the automaton's states.
	 */
	public List<State> getStates() {
		return states;
	}

	/**
	 * Sets the automaton's alphabet.
	 * 
	 * @param alphabet
	 *            the automaton's alphabet.
	 */
	public void setAlphabet(Set<String> alphabet) {
		this.alphabet = alphabet;
	}

	/**
	 * Gets the automaton's alphabet.
	 * 
	 * @return the automaton's alphabet.
	 */
	public Set<String> getAlphabet() {
		return alphabet;
	}
	
	/**
	 * Gets the Initial State from a 
	 * @return the state id of Initial State.
	 */
	public State getInitialState() {
		for (State tempState: getStates()) {
			if (tempState.isInitial()) {
				return tempState;
			}
		}
		throw new ValidationException("No initial State found");
	}
	
	/**
	 * Sets the description of the automaton.
	 * 
	 * @param description
	 *            a text describing the automaton's purpose.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Gets the description of the automaton.
	 * 
	 * @return a text describing the automaton's purpose.
	 */
	public String getDescription() {
		return description;
	}
}
