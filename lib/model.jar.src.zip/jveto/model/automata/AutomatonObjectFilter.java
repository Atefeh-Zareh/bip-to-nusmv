package jveto.model.automata;

import java.io.File;
import java.io.FileFilter;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;


/**
 * A file filter that deserializes automaton files encoded in XML format.
 */
public class AutomatonObjectFilter implements FileFilter {
	private final static Logger logger = Logger
			.getLogger(AutomatonObjectFilter.class);
	/**
	 * Default file extension.
	 */
	public final static String DEFAULT_EXT = ".*\\.xml$";
	/**
	 * The list of loaded automatons.
	 */
	private Map<File, Automaton> automatonList = new HashMap<File, Automaton>();

	String fileRegex;

	public AutomatonObjectFilter() {
		this(DEFAULT_EXT);
	}

	public AutomatonObjectFilter(String fileRegex) {
		this.fileRegex = fileRegex;
	}

	public boolean accept(File file) {
		try {
			if (!file.isDirectory()) {
				if (!file.getName().matches(fileRegex)) {
					logger.debug("Skipping " + file.getName());
					return false;
				}
				Automaton automaton = AutomatonHelper.load(file);
				automatonList.put(file, automaton);
			}
			return true;
		} catch (Exception e) {
			logger.debug("Skiping " + file.getAbsolutePath());
			return false;
		}
	}

	/**
	 * Gets the list of loaded automatons.
	 * 
	 * @return a list of loaded automatons.
	 */
	public Map<File, Automaton> getAutomatonList() {
		return automatonList;
	}

}
