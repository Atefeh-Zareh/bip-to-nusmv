package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Streett's automaton accepting pairs.
 */
@XStreamAlias("Pair")
public class Pair {
	/**
	 * Recurrent states.
	 */
	@XStreamAsAttribute
	private String R = "";
	/**
	 * Persistent states.
	 */
	@XStreamAsAttribute
	private String P = "";

	/**
	 * Constructor.
	 * 
	 * @param R
	 *            a comma separated list of states.
	 * @param P
	 *            a comma separated list of states
	 */
	public Pair(String R, String P) {
		this.setR(R);
		this.setP(P);
	}

	/**
	 * Sets the recurrent states.
	 * 
	 * @param r
	 *            recurrent states.
	 */
	public void setR(String r) {
		R = r == null ? "" : r.trim();
	}

	/**
	 * Gets the recurrent states. For consistency, if p is null it will be
	 * converted to an empty string.
	 * 
	 * @return the recurrent states.
	 */
	public String getR() {
		return R == null ? "" : R.trim();
	}

	/**
	 * Sets the persistent states. For consistency, if p is null it will be
	 * converted to an empty string.
	 * 
	 * @param p
	 *            persistent state list.
	 */
	public void setP(String p) {
		P = p == null ? "" : p.trim().replaceAll(",+$", "");
	}

	/**
	 * Gets the persistent states.
	 * 
	 * @return the persistent states.
	 */
	public String getP() {
		return P == null ? "" : P.trim().replaceAll(",+$", "");
	}

	public String toString() {
		return "(R={" + getR() + "}, P={" + getP() + "})";
	}
}
