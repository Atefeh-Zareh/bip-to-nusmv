package jveto.model.automata;

import java.util.HashMap;
import java.util.Map;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents an enforcement monitor.
 */
@XStreamAlias("EnforcementMonitor")
public class EnforcementMonitor extends IOAutomaton {
	
	public Map<String, Map<String, Transition>> getStateEventTransitionMap() {
		
		Map<String, Map<String, Transition>> returnMap = new HashMap<String,Map<String,Transition>>();
		
		for (State s : getStates()) {
			Map<String, Transition> tempMap = new HashMap<String, Transition>();
			for (Transition t : s.getTransitions()) {
				tempMap.put(t.getEvent(), t);
			}
			returnMap.put(s.getId(), tempMap);
		}
		return returnMap;
	}
}
