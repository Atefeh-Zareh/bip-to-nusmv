package jveto.model.automata;

import java.io.File;
import java.io.FileNotFoundException;

import jveto.utils.XmlSerializer;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.JDomDriver;

/**
 * Loads/saves automata from/to a file.
 * 
 * This class is not thread safe.
 */
public class AutomatonHelper {
	/**
	 * XML serializer.
	 */
	final static XmlSerializer serializer;
	
	/**
	 * Static constructor.
	 */
	static {
		XStream xstream;
		xstream = new XStream(new JDomDriver());
		xstream.alias("StreettAutomaton", StreettAutomaton.class);
		xstream.alias("DFAutomaton", DFAutomaton.class);
		xstream.alias("BuchiAutomaton", BuchiAutomaton.class);
		xstream.alias("EnforcementMonitor", EnforcementMonitor.class);
		xstream.alias("VerificationMonitor", VerificationMonitor.class);

		xstream.registerConverter(new TransitionConverter());
		xstream.registerConverter(new StateConverter());
		xstream.autodetectAnnotations(true);
		
		serializer = new XmlSerializer(xstream);
	}

	/**
	 * Private constructor.
	 */
	private AutomatonHelper() {
	}

	/**
	 * Loads an automaton from a file.
	 * 
	 * @param automatonFile
	 *            a file containing an automaton.
	 * @return an {@link Automaton}'s instance.
	 * @throws FileNotFoundException
	 *             when the file does not exists.
	 */
	public static <T extends Automaton> T load(File automatonFile)
			throws FileNotFoundException {
		return serializer.deserialize(automatonFile);
	}

	/**
	 * Saves an {@link Automaton} to a file.
	 * 
	 * @param automaton
	 *            an automaton instance.
	 * @param outputFile
	 *            the output file.
	 * @throws FileNotFoundException
	 *             when the file does not exists.
	 */
	public static void save(Automaton automaton, File outputFile)
			throws FileNotFoundException {
		serializer.serialize(automaton, outputFile);
	}
}
