package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("VerificationMonitor")
public class VerificationMonitor extends IOAutomaton {
	
}
