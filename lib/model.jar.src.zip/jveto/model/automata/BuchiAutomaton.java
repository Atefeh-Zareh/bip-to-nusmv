package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents a BuchiAutomaton
 */
@XStreamAlias("BuchiAutomaton")
public class BuchiAutomaton extends SimpleAutomaton<String> {

}