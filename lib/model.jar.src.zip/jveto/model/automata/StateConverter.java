package jveto.model.automata;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.thoughtworks.xstream.converters.ConversionException;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

class StateConverter implements Converter {
	public void marshal(Object value, HierarchicalStreamWriter writer,
			MarshallingContext context) {
		State state = (State) value;
		writer.addAttribute("id", state.getId());
		if (state.isInitial()) {
			writer.addAttribute("initial", String.valueOf(state.isInitial()));
		}
		if (state.getOutput() != null && state.getOutput().trim().length() > 0) {
			writer.addAttribute("output", state.getOutput());
		}
		if (state.getTransitions() != null) {
			context.convertAnother(state.getTransitions());
		}
	}

	@SuppressWarnings("unchecked")
	public Object unmarshal(HierarchicalStreamReader reader,
			UnmarshallingContext context) {
		Map<String, State> states = (Map<String, State>) context.get("states");
		if (states == null) {
			states = new HashMap<String, State>();
		}
		
		State state = new State(reader.getAttribute("id"));
		if (states.containsKey(state.getId())) {
			throw new ConversionException("The state " + state.getId()
					+ " is a duplicate: " + states.keySet() + ".");
		}
		states.put(state.getId(), state);
		context.put("states", states);
		context.put("currentState", state);

		if (context.get("missing" + state.getId()) != null) {
			List<Transition> transitions = (List<Transition>) context
					.get("missing" + state.getId());

			for (Transition transition : transitions) {
				transition.setNextState(state);
			}
		}

		state.setInitial(Boolean.parseBoolean(reader.getAttribute("initial")));
		if (reader.getAttribute("output") != null) {
			state.setOutput(reader.getAttribute("output"));
		}
		while (reader.hasMoreChildren()) {
			reader.moveDown();
			state.getTransitions().add(
					(Transition) context
							.convertAnother(state, Transition.class));
			reader.moveUp();
		}
		return state;
	}

	@SuppressWarnings("unchecked")
	public boolean canConvert(Class clazz) {
		return State.class.isAssignableFrom(clazz);
	}
}