package jveto.model.automata;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents a DFA.
 */
@XStreamAlias("DFAutomaton")
public class DFAutomaton extends SimpleAutomaton<String> {
	/**
	 * Converts the current DFA in its complement.
	 * 
	 * @return the complement of the <strong>current</strong> automaton's
	 *         instance.
	 */
	public DFAutomaton complement() {
		List<String> acceptingStates = new ArrayList<String>();
		acceptingStates.addAll(getAcceptingCondition());

		getAcceptingCondition().clear();

		for (State state : getStates()) {
			if (!acceptingStates.contains(state.getId())) {
				getAcceptingCondition().add(state.getId());
			}
		}
		return this;
	}
}
