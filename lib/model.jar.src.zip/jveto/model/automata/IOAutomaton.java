package jveto.model.automata;

import java.util.HashMap;
import java.util.Map;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents an input/output automaton. It is used to abstract common
 * functionality for verification or enforcement monitors.
 */
public abstract class IOAutomaton extends Automaton {
	/**
	 * The automaton's type.
	 */
	@XStreamAsAttribute
	private AutomatonKind kind;

	/**
	 * Empty constructor. By default it creates a MEALY automaton.
	 */
	public IOAutomaton() {
		kind = AutomatonKind.MEALY;
	}

	/**
	 * Gets the automaton's type.
	 * 
	 * @return the automaton's type.
	 */
	public AutomatonKind getKind() {
		return kind;
	}

	/**
	 * Sets the automaton's type.
	 * 
	 * @param kind
	 *            the type of the automaton.
	 */
	public void setKind(AutomatonKind kind) {
		this.kind = kind;
	}

	/**
	 * Indicates if the current instance is a MEALY automaton.
	 * 
	 * @return <code>true</code> if the current instance is a MEALY automaton.
	 */
	public boolean isMealy() {
		return (getKind() == AutomatonKind.MEALY);
	}

	/**
	 * Indicates if the current instance is a MOORE automaton.
	 * 
	 * @return <code>true</code> if the current instance is a MOORE automaton.
	 */
	public boolean isMoore() {
		return (getKind() == AutomatonKind.MOORE);
	}

	/**
	 * Converts the current MEALY automaton into its MOORE version.
	 * 
	 * @return a MOORE version of the automaton.
	 */
	public IOAutomaton moore() {
		if (kind == AutomatonKind.MEALY) {
			Map<String, State> statesMap = new HashMap<String, State>();

			for (State state : getStates()) {
				statesMap.put(state.getId(), state);
			}
			for (State state : getStates()) {
				for (Transition transition : state.getTransitions()) {
					State next = transition.getNextState();
					if (next == null) {
						throw new ValidationException(
								"The next state attribute should not be null.");
					}

					if (transition.getOutput() == null
							|| transition.getOutput().trim().length() == 0) {
						throw new ValidationException(
								"The automaton does not seem to be a valid mealy automaton. The 'output' attribute of transition "
										+ state.getId()
										+ "->"
										+ next.getId()
										+ " is empty.");
					}
					statesMap.get(next.getId()).setOutput(
							transition.getOutput());
					transition.setOutput(null);
				}
			}
			kind = AutomatonKind.MOORE;
		}

		return this;
	}

	/**
	 * Converts the current MOORE automaton into its MEALY version.
	 * 
	 * @return a MEALY version of the automaton.
	 */
	public IOAutomaton mealy() {
		if (kind == AutomatonKind.MOORE) {
			Map<String, State> statesMap = new HashMap<String, State>();

			for (State state : getStates()) {
				if (state.getOutput() == null
						|| state.getOutput().trim().length() == 0) {
					throw new ValidationException(
							"The automaton does not seem to be a valid moore automaton. The 'output' attribute of state '"
									+ state.getId() + "' is empty.");
				}
				statesMap.put(state.getId(), state);
				state.setOutput(null);
			}

			for (State state : getStates()) {
				for (Transition transition : state.getTransitions()) {
					State next = transition.getNextState();
					if (next == null) {
						throw new ValidationException(
								"The next state attribute should be null.");
					}
					transition.setOutput(statesMap.get(next.getId())
							.getOutput());
					// Fix references
					transition.setNextState(statesMap.get(next.getId()));
				}
			}

			kind = AutomatonKind.MEALY;
		}
		return this;
	}

}
