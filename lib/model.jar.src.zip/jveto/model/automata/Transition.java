package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Represents a transition between two states.
 */
@XStreamAlias("Transition")
public class Transition {
	/**
	 * The transition label.
	 */
	private String event;
	/**
	 * The next state.
	 */
	private State nextState;
	/**
	 * The starting point of the transition.
	 */
	private State sourceState;
	/**
	 * The transition's output.
	 */
	private String output;

	/**
	 * Constructor.
	 * @param event the transition label.
	 * @param next the next state.
	 */
	public Transition(String event, State next) {
		this.setEvent(event);
		this.setNextState(next);
	}
	
	/**
	 * Constructor.
	 * @param event the transition label.
	 * @param next the next state.
	 * @param source the source state.
	 */
	public Transition(String event, State next, State source) {
		this.setEvent(event);
		this.setNextState(next);
		this.setSourceState(source);
	}

	/**
	 * Constructor.
	 */
	public Transition() {
	}

	/**
	 * Sets the next state.
	 * @param next the next state.
	 */
	public void setNextState(State next) {
		this.nextState = next;
	}

	/**
	 * Gets the next state.
	 * @return the next state.
	 */
	public State getNextState() {
		return nextState;
	}

	/**
	 * Sets the transition label.
	 * @param event a label for the transition.
	 */
	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * Gets the transition label.
	 * @return the transition label.
	 */
	public String getEvent() {
		return event;
	}

	/**
	 * Sets the starting state of the transition.
	 * @param sourceState the starting state of the transition.
	 */
	public void setSourceState(State sourceState) {
		this.sourceState = sourceState;
	}

	/**
	 * Gets the starting state of the transition.
	 * @return the starting state of the transition.
	 */
	public State getSourceState() {
		return sourceState;
	}

	/**
	 * Sets the transition's output.
	 * @param output the transition's output.
	 */
	public void setOutput(String output) {
		this.output = output;
	}

	/**
	 * Gets the transition's output.
	 * @return the transition's output.
	 */
	public String getOutput() {
		return output;
	}
	
	public String toString() {
		return getEvent() + "->" + (nextState == null ? "null" : nextState.getId());
	}
}
