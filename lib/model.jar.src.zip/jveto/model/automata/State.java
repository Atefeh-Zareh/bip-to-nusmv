package jveto.model.automata;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 * Represents an automaton's state.
 * 
 */
@XStreamAlias("State")
public class State {
	/**
	 * State's id.
	 */
	@XStreamAsAttribute
	private String id;
	@XStreamAsAttribute
	/*
	 * * Defines if the state is part of the automaton's initial states set.
	 */
	private boolean initial;
	/**
	 * The state's ouput.
	 */
	@XStreamAsAttribute
	private String output;

	/**
	 * Transitions list.
	 */
	@XStreamImplicit
	private List<Transition> transitions;

	/**
	 * Constructor.
	 */
	public State() {
		transitions = new ArrayList<Transition>();
	}

	/**
	 * Constructor.
	 * 
	 * @param id
	 *            a state's id.
	 */
	public State(String id) {
		this();
		this.id = id;
	}

	/**
	 * Gets the state's id.
	 * 
	 * @return the state's id.
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets if the current state is a initial state.
	 * 
	 * @param initial
	 *            a flag indicating if the current state is a initial state.
	 */
	public void setInitial(boolean initial) {
		this.initial = initial;
	}

	/**
	 * Indicates if the current state is a initial state.
	 * 
	 * @return a flag indicating if the current state is a initial state.
	 */
	public boolean isInitial() {
		return initial;
	}

	/**
	 * Gets the transition list.
	 * @return the transition list.
	 */
	public List<Transition> getTransitions() {
		return transitions;
	}

	/**
	 * Sets the state's output.
	 * @param output the state's output.
	 */
	public void setOutput(String output) {
		this.output = output;
	}

	/**
	 * Gets the state's output.
	 * @return the state's output.
	 */
	public String getOutput() {
		return output;
	}
	
	public String toString() {
		return id ;// + "" + transitions;
	}
}
