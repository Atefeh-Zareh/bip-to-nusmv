package jveto.model.automata;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.DataHolder;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

class TransitionConverter implements Converter {

	public void marshal(Object value, HierarchicalStreamWriter writer,
			MarshallingContext context) {
		Transition transition = (Transition) value;
		writer.addAttribute("event", transition.getEvent());
		if (transition.getNextState() != null) {
			writer.addAttribute("nextState", transition.getNextState().getId());
		}
		if (transition.getOutput() != null) {
			writer.addAttribute("output", transition.getOutput());
		}
	}

	@SuppressWarnings("unchecked")
	public Object unmarshal(HierarchicalStreamReader reader,
			UnmarshallingContext context) {
		Transition transition = new Transition();
		transition.setEvent(reader.getAttribute("event"));

		Map<String, State> states = (Map<String, State>) context.get("states");

		transition.setSourceState((State) context.get("currentState"));
		transition.setNextState(states.get(reader.getAttribute("nextState")));
		
		transition.setOutput(reader.getAttribute("output"));
		if (transition.getNextState() == null) {
			List<Transition> missingRefs = contextItem("missing"
					+ reader.getAttribute("nextState"), context,
					new ArrayList<Transition>());

			missingRefs.add(transition);
		}

		return transition;
	}

	@SuppressWarnings("unchecked")
	public boolean canConvert(Class clazz) {
		return Transition.class.isAssignableFrom(clazz);
	}

	private <T> T contextItem(String key, DataHolder context, T initValue) {
		@SuppressWarnings("unchecked")
		T item = (T) context.get(key);
		if (item == null) {
			context.put(key, item = initValue);
		}
		return item;
	}

}
