package jveto.model.automata;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("AutomatonKind")
/**
 * Defines de type of automata.
 */
public enum AutomatonKind {
	MEALY, MOORE
}
