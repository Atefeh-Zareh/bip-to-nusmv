package jveto.model.automata;

import com.thoughtworks.xstream.converters.ConversionException;

/**
 * Used to indicate errors during automata completeness validation.
 */
public class ValidationException extends RuntimeException {
	private static final long serialVersionUID = -1827478763482092427L;

	public ValidationException(String message) {
		this(message, null);
	}

	public ValidationException(String message, ConversionException e) {
		super(message, e);
	}

}
