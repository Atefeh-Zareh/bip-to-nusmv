package jveto.model.automata;

import java.io.File;
import java.io.FileFilter;
import java.net.URL;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.Filter;
import org.jdom.input.SAXBuilder;

/**
 * A file filter that recognizes automaton files encoded in XML format.
 */
public class AutomatonFilter implements FileFilter {
	private final static Logger logger = Logger.getLogger(AutomatonFilter.class);
	private final static String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
	private final static String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
	private final static String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
	/**
	 * Default file extension.
	 */
	public final static String DEFAULT_EXT = ".*\\.xml$";

	/**
	 * Regular expression that will be evaluated against file names.
	 */
	private String fileRegex;

	/**
	 * To perform a simple validation based on a XML element that characterizes
	 * the automaton.
	 */
	private Filter rootFilter;

	/**
	 * To perform XSD validation.
	 */
	private SAXBuilder documentBuilder;

	/**
	 * Default constructor.
	 */
	public AutomatonFilter() {
		this(DEFAULT_EXT, ".*automaton");
	}

	/**
	 * Constructor.
	 * 
	 * @param fileRegex
	 *            a regular expression that will be evaluated against file
	 *            names.
	 * @param rootElement
	 */
	public AutomatonFilter(String fileRegex, String rootElement) {
		this.fileRegex = fileRegex;
		this.documentBuilder = new SAXBuilder();
		rootFilter = new RootElementFilter(rootElement);
	}

	/**
	 * Constructor.
	 * 
	 * @param fileRegex
	 *            a regular expression that will be evaluated against file
	 *            names.
	 * @param xsdSchema
	 *            a XSD schema to validate the files.
	 */
	public AutomatonFilter(String fileRegex, URL xsdSchema) {
		this(fileRegex, "automaton");
		documentBuilder.setProperty(JAXP_SCHEMA_LANGUAGE, W3C_XML_SCHEMA);
		documentBuilder.setProperty(JAXP_SCHEMA_SOURCE, new File(xsdSchema
				.getPath()));
		documentBuilder.setValidation(true);
	}

	public boolean accept(File file) {
		if (!file.isDirectory()) {
			if (!file.getName().matches(fileRegex)) {
				logger.debug("Skipping " + file.getName());
				return false;
			}
			if (documentBuilder != null) {
				try {
					Document document = documentBuilder.build(file
							.getAbsolutePath());

					/*
					 * Provide a simple way to validate automatons if a XSD
					 * schema is not available.
					 */

					if (!documentBuilder.getValidation()
							&& !document.getDescendants(rootFilter).hasNext()) {
						logger.debug("Skipping " + file.getName());
						return false;
					}

				} catch (Exception e) {
					logger.error("Skipping " + file.getName(), e);
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * A basic filter to check the validity of an automaton.
	 */
	class RootElementFilter implements Filter {
		private static final long serialVersionUID = -8681330301215374019L;
		/**
		 * an element that characterizes the automaton.
		 */
		private String rootElement;

		/**
		 * Constructor.
		 * 
		 * @param rootElement
		 *            an element that characterizes the automaton.
		 */
		public RootElementFilter(String rootElement) {
			this.rootElement = rootElement;
		}

		public boolean matches(Object node) {
			if (!(node instanceof Element)) {
				return false;
			}
			Element element = (Element) node;
			return element.getName().matches(rootElement);
		}
	}

}
