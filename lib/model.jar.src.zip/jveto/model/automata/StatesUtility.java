package jveto.model.automata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

/**
 * Removes unreachable states of an automaton.
 * 
 */
public class StatesUtility {
	/**
	 * Logger.
	 */
	private final static Logger logger = Logger.getLogger(StatesUtility.class);

	private StatesUtility() {
	}

	/**
	 * Removes unreachable states from an automaton that is contained in a file
	 * and saves it back.
	 * 
	 * @param file
	 *            a file pointing to an automaton.
	 * @throws FileNotFoundException
	 *             when the file does not exist.
	 */
	public static void reduceStates(File file) throws FileNotFoundException {
		logger.debug("[->Reducing states for " + file.getName());
		Automaton automaton = AutomatonHelper.load(file);
		reduceStates(automaton);
		/*
		 * Update the XML file.
		 */
		logger.debug("Saving the automaton to " + file.getName());
		AutomatonHelper.save(automaton, file);
		logger.debug("<-]");
	}

	/**
	 * Removes unreachable states.
	 * 
	 * @param automaton
	 *            an automaton.
	 */
	public static void reduceStates(Automaton automaton) {
		Map<String, State> states = new HashMap<String, State>();
		State initial = automaton.getInitialState();

		for (State state : automaton.getStates()) {
			states.put(state.getId(), state);
		}
		logger.debug("Initial State: " + initial.getId()
				+ ", Number of States: " + automaton.getStates().size());

		/*
		 * Find the reachable states starting from the initial state.
		 */
		Set<State> reachable = new HashSet<State>();
		reduceStates(initial, states, reachable);

		/*
		 * Remove unreachable states.
		 */
		automaton.getStates().clear();
		automaton.getStates().addAll(reachable);

		if (automaton instanceof StreettAutomaton) {
			removeAccepting((StreettAutomaton) automaton, states.values(),
					reachable);
		}

	}

	private static void removeAccepting(StreettAutomaton automaton,
			Collection<State> states, Set<State> reachable) {
		/*
		 * HACK: Build a regular expression to update accepting pairs because
		 * they are only strings. We should maybe change it in the future.
		 * 
		 * \b(state_id1|state_id2|state_id3)\b
		 */
		logger.debug("Removing unreachable states "
				+ "from the accepting condition.");

		String regExp = "\\b(";
		for (State state : states) {
			if (reachable.contains(state))
				continue;
			logger.debug("Deleting unreachable state " + state.getId());
			regExp += Pattern.quote(state.getId()) + "|";
		}
		if (regExp.endsWith("|")) {
			regExp = regExp.substring(0, regExp.length() - 1);
		}
		regExp += ")\\b,?";
		
		/*
		 * Do nothing if all states are reachable.
		 */
		if (regExp.length() == 8) {
			return;
		}

		/*
		 * Update accepting pairs.
		 */
		for (Pair pair : automaton.getAcceptingCondition()) {
			if (pair.getP().length() > 0) {
				pair.setP(pair.getP().replaceAll(regExp, ""));
			}
			if (pair.getR().length() > 0) {
				pair.setR(pair.getR().replaceAll(regExp, ""));
			}
		}
	}

	/**
	 * Removes unreachable states.
	 * 
	 * @param currentState
	 *            the current state that is evaluated.
	 * @param states
	 *            the list of states.
	 * @param reachable
	 *            the list of reachable states.
	 */
	private static void reduceStates(State currentState,
			Map<String, State> states, Set<State> reachable) {
		logger.debug("Keeping state " + currentState.getId());
		reachable.add(currentState);
		for (Transition transition : currentState.getTransitions()) {
			State state = transition.getNextState();

			if (state == null) {
				throw new ValidationException("The state "
						+ currentState.getId()
						+ " has a transition with no arriving state.");
			}
			if (!reachable.contains(state)) {
				reduceStates(state, states, reachable);
			}
		}
	}
}
