package jveto.model.automata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * Verifies the soundness of Streett, DFA and Büchi automata.
 * 
 */
public class AutomatonValidator {
	/**
	 * Logger.
	 */
	final static Logger logger = Logger.getLogger(AutomatonValidator.class);
	
	/**
	 * Tell if soundness verification needs to be done 
	 */
	private static boolean checkSoundness = false;
	

	/**
	 * Verifies the soundness of Streett, DFA and Büchi automata.
	 * 
	 * @param automatonFilename
	 *            a filename containing a Streett, DFA or Büchi automaton
	 * @throws FileNotFoundException
	 *             when the file does not exist.
	 * @throws ValidationException
	 *             when the automaton is not complete, not deterministic or
	 *             contains unknown symbols (not listed in the alphabet).
	 */
	public static void verifySoundness(String automatonFilename, boolean checkSoundness)
			throws FileNotFoundException {
		verifySoundness(new File(automatonFilename), checkSoundness);
	}

	/**
	 * Verifies the soundness of Streett, DFA and Büchi automata.
	 * 
	 * @param automatonFile
	 *            a {@link File} pointing to a Streett, DFA or Büchi automaton
	 * @param checkSoundness
	 * 			  tell if soundness verification has to be done
	 * @throws FileNotFoundException
	 *             when the file does not exist.
	 * @throws ValidationException
	 *             when the automaton is not complete, not deterministic or
	 *             contains unknown symbols (not listed in the alphabet).
	 */
	public static void verifySoundness(File automatonFile, boolean soundness)
			throws FileNotFoundException {
		checkSoundness = soundness;
		logger.info("\n");
		logger
				.info("Verifying soundness of "
						+ automatonFile.getAbsolutePath());
		verifySoundness(AutomatonHelper.load(automatonFile));
	}

	/**
	 * Verifies the soundness of Streett, DFA and Büchi automata.
	 * 
	 * @param automaton
	 *            a {@link StreettAutomaton}, {@link BuchiAutomaton}
	 *            {@link DFAutomaton} automaton.
	 * @throws ValidationException
	 *             when the automaton is not complete, not deterministic or
	 *             contains unknown symbols (not listed in the alphabet).
	 */
	public static void verifySoundness(Automaton automaton) {
		if (automaton == null) {
			throw new ValidationException(
					"The automaton was not correctly loaded.");
		}
		Set<String> alphabet = automaton.getAlphabet();
		if (alphabet == null) {
			throw new ValidationException(
					"The automaton should have an alphabet.");
		}

		/*
		 * Make sure that alphabet symbols are unique.
		 */
		logger.debug("Alphabet: " + alphabet);

		/*
		 * Verify that the automaton has at least one state.
		 */
		List<State> states = automaton.getStates();
		if (states == null || states.size() < 1) {
			throw new ValidationException(
					"The automaton should have at least one state.");
		}

		for (State state : states) {
			checkStateSoundness(state, alphabet);
		}
	}

	/**
	 * Verifies if a state uses all the symbols defined in the alphabet and also
	 * that they are not repeated or unknown.
	 * 
	 * @param state
	 *            a state of the automaton.
	 * @param alphabet
	 *            the automaton's alphabet.
	 * @throws ValidationException
	 *             when the automaton is not complete, not deterministic or
	 *             contains unknown symbols (not listed in the alphabet).
	 */
	private static void checkStateSoundness(State state, Set<String> alphabet) {

		HashSet<String> usedSymbols = new HashSet<String>();

		logger.debug("Verifying state " + state.getId());
		for (Transition transition : state.getTransitions()) {
			String symbol = transition.getEvent().trim();

			if (usedSymbols.contains(symbol)) {
				throw new ValidationException(
						"The automaton is not deterministic. There is another transition "
								+ "with the same symbol '" + symbol
								+ "' in the state '" + state.getId() + "'.");
			} else {

				if (!alphabet.contains(symbol)) {
					if (transition.getNextState() != null) {
						throw new ValidationException("The symbol '" + symbol
								+ "' used in the transition ['" + state.getId()
								+ "' -> '" + transition.getNextState().getId()
								+ "'] does not exist in the alphabet "
								+ alphabet + ".");
					} else {
						throw new ValidationException("The symbol '" + symbol
								+ "' used in the state '" + state.getId()
								+ "' does not exist in the alphabet" + alphabet
								+ ".");
					}
				}

				usedSymbols.add(symbol);
			}
		}
		logger.debug("Used symbols in state " + state.getId() + ": "
				+ usedSymbols);

		/*
		 * To determine if the current state is complete, we check if the list
		 * of used symbols and the alphabet are of the same size. We ensure this
		 * property because there are not duplicate elements in HashSets (we
		 * test for determinism before to add symbols to usedSymbols).
		 */
		if(checkSoundness){
			if (usedSymbols.size() != alphabet.size()) {
				// Retrieve unused symbols to show a better error message.
				HashSet<String> unusedSymbols = new HashSet<String>();

				unusedSymbols.addAll(alphabet);
				unusedSymbols.removeAll(usedSymbols);

				throw new ValidationException(
						"The automaton is not complete. You should use the following missing symbols in the state '"
						+ state.getId() + "': " + unusedSymbols + ".");
			}
		}
	}
}