package jveto.model.automata;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * Defines common features for automata that require accepting condition.
 */
public abstract class SimpleAutomaton<T> extends Automaton {
	/**
	 * The accepting condition.
	 */
	@XStreamAlias("AcceptingCondition")
	private List<T> acceptingCondition;
	
	/**
	 * Constructor.
	 */
	public SimpleAutomaton() {
		acceptingCondition = new ArrayList<T>();
	}
	
	/**
	 * Gets the accepting condition.
	 * @return the accepting condition.
	 */
	public List<T> getAcceptingCondition(){
		return acceptingCondition;
	}
}
