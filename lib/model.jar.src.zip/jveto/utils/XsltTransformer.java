package jveto.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jdom.transform.JDOMResult;
import org.jdom.transform.JDOMSource;

/**
 * A XSLT transformer utility. It allows to pass parameters to XSLT templates.
 */
public class XsltTransformer {
	/**
	 * Document builder.
	 */
	private static SAXBuilder docBuilder = new SAXBuilder();
	/**
	 * Document transformer factory.
	 */
	private static TransformerFactory factory = TransformerFactory
			.newInstance();
	/**
	 * Logger.
	 */
	static Logger logger = Logger.getLogger(XsltTransformer.class);

	/**
	 * Performs a XSLT transformation.
	 * 
	 * @param automatonFile
	 *            a file pointing to an automaton.
	 * @param xsltFile
	 *            a XSLT template.
	 * @param outputFile
	 *            the output file.
	 * @throws IOException when required files are not found or are incorrect. 
	 */
	public static void transform(String automatonFile, String xsltFile,
			String outputFile) throws IOException {
		transform(new File(automatonFile), xsltFile, outputFile, null);
	}

	/**
	 * Performs a XSLT transformation.
	 * 
	 * @param automatonFile
	 *            a file pointing to an automaton.
	 * @param xsltFile
	 *            a XSLT template.
	 * @param outputFile
	 *            the output file.
	 * @throws IOException when required files are not found or are incorrect.
	 */
	public static void transform(File automatonFile, String xsltFile,
			String outputFile, Map<String, Object> parameters)
			throws IOException {

		try {
			logger.info("");
			logger.info("Trying to transform "
					+ automatonFile.getAbsolutePath());
			logger.debug("XSLT Template: " + xsltFile);
			logger.debug("Output File: " + outputFile);

			Document document = docBuilder.build(automatonFile);

			JDOMResult out = new JDOMResult();

			StreamSource source;
			if (new File(xsltFile).exists()) {
				source = new StreamSource(xsltFile);
			} else if (XsltTransformer.class.getClassLoader().getResource(
					xsltFile) != null) {
				source = new StreamSource(XsltTransformer.class
						.getClassLoader().getResourceAsStream(xsltFile));
			} else {
				throw new IOException("The XSLT template was not found.");
			}
			Transformer transformer = factory.newTransformer(source);

			if (parameters != null && parameters.size() > 0) {
				logger.debug("XSLT parameters:" + parameters);
				for (Map.Entry<String, Object> param : parameters.entrySet()) {
					transformer.setParameter(param.getKey(), param.getValue());
				}
			}
			transformer.transform(new JDOMSource(document), out);

			Document resultat = out.getDocument();

			XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
			outputter.output(resultat, new FileOutputStream(outputFile));
			logger.info("XSLT transformation has been successfully finished. Ouput file: " + outputFile);
		} catch (TransformerException e) {
			logger.error("Unable to perform a XSLT transformation on '"
					+ automatonFile.getName() + "'.", e);
		} catch (IOException e) {
			logger.error("Unable to process file '" + automatonFile.getName()
					+ "'.", e);
			throw e;
		} catch (JDOMException e) {
			logger.error("Unable to load the file '" + automatonFile.getName()
					+ "'.", e);
		}
	}
}
