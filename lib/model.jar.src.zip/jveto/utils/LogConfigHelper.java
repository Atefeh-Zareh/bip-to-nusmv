package jveto.utils;

import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

/**
 * Log4j config helper.
 */
public class LogConfigHelper {
	/**
	 * Default log4j configuration.
	 */
	private static Properties defaultConfig;
	/**
	 * Default log4j property file.
	 */
	final static String log4jConf = "/ressources/log4j.properties";

	static {
		defaultConfig = new Properties();

		defaultConfig.setProperty("log4j.rootLogger", "INFO, A1");
		defaultConfig.setProperty("log4j.appender.A1",
				"org.apache.log4j.ConsoleAppender");
		defaultConfig.setProperty("log4j.appender.A1.layout",
				"org.apache.log4j.PatternLayout");
		defaultConfig.setProperty("log4j.appender.A1.layout.ConversionPattern",
				"%m%n");
	}
	
	/**
	 * Configures the current log4j instance with the default configuration file.
	 * 
	 * <strong>Note:<strong> This method should be called once (preferably at
	 * main method). Otherwise, unexpected issues may happen (i.e. repeated log
	 * messages).
	 * 
	 * @param debug
	 *            a boolean value indicating if debug messages should be logged.
	 */
	public static void init(boolean debug) {
		init(log4jConf, debug);
	}

	/**
	 * Configures the current log4j instance.
	 * 
	 * <strong>Note:<strong> This method should be called once (preferably at
	 * main method). Otherwise, unexpected issues may happen (i.e. repeated log
	 * messages).
	 * 
	 * @param configFile
	 *            a file containing the log4j configuration file.
	 * @param debug
	 *            a boolean value indicating if debug messages should be logged.
	 */
	public static void init(String configFile, boolean debug) {
		Properties config = new Properties();
		try {
			config.load(LogConfigHelper.class.getResourceAsStream(log4jConf));
		} catch (Exception e) {
			config = (Properties) defaultConfig.clone();
		}

		if (debug) {
			config.setProperty("log4j.rootLogger", "DEBUG,A1");
		}

		PropertyConfigurator.configure(config);
	}
}
