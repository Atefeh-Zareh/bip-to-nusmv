package jveto.utils;

import org.apache.commons.collections.map.AbstractReferenceMap;
import org.apache.commons.collections.map.ReferenceIdentityMap;

/**
 * @author Eric Bodden
 */
public class WeakIdentityHashMap extends ReferenceIdentityMap {

    /**
     * 
     */
    public WeakIdentityHashMap() {
        super(AbstractReferenceMap.WEAK, AbstractReferenceMap.WEAK, true);
    }


}
