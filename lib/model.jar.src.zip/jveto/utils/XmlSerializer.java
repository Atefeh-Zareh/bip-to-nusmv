package jveto.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.ConversionException;

/**
 * Provides XML serialization and deserialization of java objects.
 */
public class XmlSerializer {
	/**
	 * XML serializer/deserializer
	 */
	private XStream xstream;

	/**
	 * Constructor.
	 * 
	 * @param xstream
	 *            a (de)serializer properly configured.
	 */
	public XmlSerializer(XStream xstream) {
		this.xstream = xstream;
	}

	/**
	 * Deserializes a java object encoded in XML format.
	 * 
	 * @param objectLocation
	 *            a file containing the java object encoded in XML.
	 * @return an object instance.
	 * @throws FileNotFoundException
	 *             when the file does not exists.
	 */
	@SuppressWarnings("unchecked")
	public <T> T deserialize(File objectLocation) throws FileNotFoundException {
		try {
			return (T) xstream.fromXML(new BufferedReader(new FileReader(
					objectLocation)));
		} catch (ConversionException e) {
			ClassCastException ex = new ClassCastException(
					"The file contains an invalid object.");
			ex.initCause(e);
			throw ex;
		}
	}

	/**
	 * Serializes an object to a file.
	 * 
	 * @param object
	 *            an object instance.
	 * @param outputFile
	 *            the output file.
	 * @throws FileNotFoundException
	 *             when the file does not exists.
	 */
	public void serialize(Object object, File outputFile)
			throws FileNotFoundException {
		if (object == null) {
			throw new IllegalArgumentException(
					"The parameter 'object' can not be null.");
		}
		xstream.toXML(object, new PrintWriter(outputFile));
	}
}
