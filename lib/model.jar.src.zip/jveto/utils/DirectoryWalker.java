package jveto.utils;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;

/**
 * Traverses the contents of a directory selecting only the relevant files.
 * 
 * Is a slight modification of http://vafer.org/blog/20071112204524
 * 
 */
public abstract class DirectoryWalker {
	/**
	 * Logger.
	 */
	final static Logger logger = Logger.getLogger(DirectoryWalker.class);
	/**
	 * Flag to indicate if the all the directory tree should be considered.
	 */
	private boolean recursive;
	/**
	 * Filter to select relevant files.
	 */
	private FileFilter fileFilter;
	/**
	 * The working directory.
	 */
	private File rootDir;
	/**
	 * The output path.
	 */
	private File outputPath;

	/**
	 * Creates a DirectoryWalker instance that does not have a file filter.
	 * 
	 * @param rootDir
	 *            the root directory.
	 * @param recursive
	 *            Flag to indicate if the all the directory tree should be
	 *            considered.
	 */
	public DirectoryWalker(File rootDir, boolean recursive) {
		this(rootDir, recursive, null);
	}

	/**
	 * Creates a DirectoryWalker instance with a file filter to select the
	 * relevant files.
	 * 
	 * @param rootDir
	 *            the root directory.
	 * @param recursive
	 *            flag to indicate if the all the directory tree should be
	 *            considered.
	 * @param fileFilter
	 *            filter to select only relevant files.
	 */
	public DirectoryWalker(File rootDir, boolean recursive,
			FileFilter fileFilter) {
		setRoot(rootDir);
		this.recursive = recursive;
		this.fileFilter = fileFilter;
	}

	/**
	 * Sets the root or working directory.
	 * 
	 * @param root
	 *            the root directory.
	 */
	public void setRoot(final File root) {
		if (root.isDirectory()) {
			this.rootDir = root;
		} else {
			this.rootDir = root.getAbsoluteFile().getParentFile();
		}
	}

	/**
	 * Traverses the contents of the root directory.
	 * 
	 * @throws IOException
	 *             when the root directory is not found.
	 */
	public final void traverse() throws IOException {
		if (getRootDirectory() != null && getRootDirectory().exists()) {
			traverse(getRootDirectory());
		} else {
			throw new FileNotFoundException();
		}
	}

	/**
	 * Traverses the contents of the selected directory or file.
	 * 
	 * @param f
	 *            a directory or file where the traversal should begin.
	 * @throws IOException
	 *             if the path does not exist.
	 */
	public final void traverse(final File f) throws IOException {
		if (!f.exists()) {
			throw new FileNotFoundException(f.getAbsolutePath());
		}
		if (f.isDirectory()) {
			onDirectory(f);
			final File[] childs;

			if (fileFilter != null) {
				childs = f.listFiles(fileFilter);
			} else {
				childs = f.listFiles();
			}

			if (childs != null) {
				logger.info("Current directory: " + f.getName() + ", "
						+ childs.length + " files found.\n");
				for (File child : childs) {
					if (child.isFile() || recursive && child.isDirectory()) {
						traverse(child);
					}
				}
			}
		} else {
			onFile(f);
		}
	}

	/**
	 * Event that is called when a directory is found.
	 * 
	 * @param d
	 *            the current directory.
	 * @throws IOException
	 *             the directory does not exist.
	 */
	public void onDirectory(final File d) throws IOException {
	}

	/**
	 * Event that is called when a file is found.
	 * 
	 * @param f
	 *            the current file
	 * @throws IOException
	 *             the file does not exist.
	 */
	public void onFile(final File f) throws IOException {
	}

	/**
	 * Gets the root directory.
	 * 
	 * @return the root directory.
	 */
	public File getRootDirectory() {
		return rootDir;
	}

	/**
	 * Sets the output path. If a null or invalid path is provided, it will use
	 * the root directory as the output path.
	 * 
	 * @param outputPath
	 *            the output path.
	 */
	public void setOutputPath(File outputPath) {
		if (outputPath == null) {
			outputPath = rootDir;
		} else if (!outputPath.exists() && outputPath.isDirectory()) {
			if (outputPath.isFile()) {
				outputPath = outputPath.getParentFile();
			}
			outputPath.mkdirs();
		} else if (outputPath.isFile() && rootDir.isDirectory()) {
			outputPath = outputPath.getParentFile();
		}
		this.outputPath = outputPath;
	}

	/**
	 * Gets the output path.
	 * 
	 * @return the output path.
	 */
	public File getOutputPath() {
		return outputPath;
	}

	/**
	 * Gets the output file path preserving the same structure of the input
	 * file.
	 * 
	 * @param file
	 *            an input path.
	 * @return the output file path.
	 */
	protected String getOutputFile(File file) {
		String output = outputPath.getAbsolutePath();

		/*
		 * Fix the output file.
		 */
		if (outputPath.isDirectory()) {
			// Create the same structure if needed.
			output = file.getAbsoluteFile().getParentFile().getAbsolutePath()
					.replace(rootDir.getAbsolutePath(), "");

			output = outputPath.getAbsolutePath() + output + File.separator
					+ file.getName();

			new File(output).getParentFile().mkdirs();
		}
		return output;
	}
}
