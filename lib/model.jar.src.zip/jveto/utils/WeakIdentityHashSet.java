package jveto.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * @author Eric Bodden
 */
public class WeakIdentityHashSet implements Set {

    protected WeakIdentityHashMap delegate;
    
    /**
     * 
     */
    public WeakIdentityHashSet() {
        delegate = new WeakIdentityHashMap();
    }

    /**
     * {@inheritDoc}
     */
    public int size() {
        return delegate.size();
    }

    /**
     * {@inheritDoc}
     */
    public boolean isEmpty() {
        return delegate.isEmpty();
    }

    /**
     * {@inheritDoc}
     */
    public boolean contains(Object o) {
        return delegate.containsKey(o);
    }

    /**
     * {@inheritDoc}
     */
    public Iterator iterator() {
        return delegate.keySet().iterator();
    }

    /**
     * {@inheritDoc}
     */
    public Object[] toArray() {
        return delegate.keySet().toArray();
    }

    /**
     * {@inheritDoc}
     */
    public Object[] toArray(Object[] a) {
        return delegate.keySet().toArray(a);
    }

    /**
     * {@inheritDoc}
     */
    public boolean add(Object o) {
        return delegate.put(o, o)!=null;
    }

    /**
     * {@inheritDoc}
     */
    public boolean remove(Object o) {
        return delegate.remove(o)!=null;
    }

    /**
     * {@inheritDoc}
     */
    public boolean containsAll(Collection c) {
        return delegate.keySet().containsAll(c);
    }

    /**
     * {@inheritDoc}
     */
    public boolean addAll(Collection c) {
        boolean b = true;
        for (Iterator iter = c.iterator(); iter.hasNext();) {
            Object o = (Object) iter.next();
            b &= add(o);
        }
        return b;
    }

    /**
     * {@inheritDoc}
     */
    public boolean retainAll(Collection c) {
        throw new NotImplementedException();
    }

    /**
     * {@inheritDoc}
     */
    public boolean removeAll(Collection c) {
        boolean b = true;
        for (Iterator iter = c.iterator(); iter.hasNext();) {
            Object o = (Object) iter.next();
            b &= remove(o);
        }
        return b;
    }

    /**
     * {@inheritDoc}
     */
    public void clear() {
        delegate.entrySet().clear();
    }
}
