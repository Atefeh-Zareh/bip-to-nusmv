package epfl.risd.bip.nusmv.expression;

public interface NuExpression extends NuAction {

}